<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
#Test
$config['debug_quyeba_client'] = 'default';
$config['debug_quyeba_client_key'] = 'default';
$config['debug_quyeba_api_url'] = 'http://beta.qybimg.com/api/v2/mobile/';
#Production
$config['quyeba_client'] = 'shake_shake';
$config['quyeba_client_key'] = '8ujok937788nnnnjkhytrewsdcxlop';
$config['quyeba_api_url'] = 'http://www.quyeba.com/api/v2/mobile/';

#Reward points
$config['reward_points_api_url'] = 'http://www.thenorthface.com.cn/explorer/api/integral.php';
$config['reward_points_api_key'] = 'explorer1234!@';

#Global
$config['enable_validate_sign'] = false;
$config['coupon_per_user'] = 1;
$config['debug_environment'] = false;
